//
//  EditViewController.h
//  Tumblr
//
//  Created by Alice Tsai on 3/21/14.
//  Copyright (c) 2014 Alice Tsai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EditViewController : UIViewController

@end
