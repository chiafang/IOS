//
//  AccountViewController.m
//  Tumblr
//
//  Created by Alice Tsai on 3/21/14.
//  Copyright (c) 2014 Alice Tsai. All rights reserved.
//

#import "AccountViewController.h"
#import "LoginViewController.h"

@interface AccountViewController ()
@property (nonatomic, strong   ) LoginViewController *loginview;
- (IBAction)OnButton_signin:(id)sender;
- (IBAction)onButton_login:(id)sender;


@end

@implementation AccountViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.loginview = [[LoginViewController alloc] init];
    }

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)OnButton_signin:(id)sender {
}

- (IBAction)onButton_login:(id)sender {

    [self presentViewController:self.loginview animated:YES completion:nil];
    
    
    self.loginview.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
    //[self presentViewController:FBFeedView animated:YES completion:nil];
    
    
//    [NSThread sleepForTimeInterval:3.0];
    // NSlog (after 3 second, we can flip to fb feed main page);
    
    
    //create navigation controller and then initiate from fbfeedcontroller

    
}
@end
